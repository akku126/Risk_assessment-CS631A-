Risk analysis and assessment:Risk assessment is the process of determining the likelihood of threats being used against the vulnerabilities present 
in a system component and drawing conclusions about the resulting impact when a successful compromise occurs.

Requirements:
1.Updated internet browser to run the Html files
2.Django should be installed in your system to run a local server.

Execution:
1. Extract the zip file provided and browse to the folder named "code" which has all the project code files in it.
2. Open a Shell/terminal/command prompt in current folder location.
3. Install django if not installed already by executing command "conda install -c anaconda django" in temrinal window.
4. Then run the command to run the local server to host web app that we built by executing "python manage.py runserver"
5. It will show you a http server link if everything executed perfectly something like "http://127.0.0.1:8000/"
6. Copy and paste the above URL in browser preferably Google Chrome.
7. Now you can use this website for doing Risk assesment for your organization.